import express from "express";
import multer from "multer";
import { addImage, addTOCart, adminLogin, adminRegister, createOrder, deleteCart, deleteEvent, deleteImages, deleteSingleCartItem, downloadImages, eventlist, galleryLogin, getAllImages, getAllImagesViaEventId, getAllListItems, getCartItems, getLastReceipt, updateEventList, updateImages, updateStatus, verifyPayment} from "../controller/userAuth.js";
import { db } from "../connect.js";
import { extname } from "path";


const router = express.Router();
// gallery-image-upload
const otherStorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "gallery/");
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + "-" + Date.now() + extname(file.originalname));
    },
  });
  
  const gallery = multer({ storage: otherStorage });
  router.post("/add-gallery-image", gallery.array("image"), addImage);
  router.put("/update-image/:id", updateImages);
  router.delete("/deleteImages/:id", deleteImages); 
  router.post("/admin-login", adminLogin);
  router.post("/add-eventlist", eventlist);
  router.delete("/event-delete/:eventId", deleteEvent);
  router.put("/updateEventList/:id", updateEventList); 


router.get("/getallImages", getAllImages);
router.post("/create-order", createOrder);
router.post("/gallery-login", galleryLogin);
router.post("/add-to-cart", addTOCart);
router.get("/getCartItems/:userId", getCartItems);
router.delete("/deleteCartItems/:userId", deleteCart);
router.delete("/cart-items-delete/:userId/:itemId", deleteSingleCartItem);
router.get("/getAllListItems", getAllListItems);
router.get("/getAllImagesViaEventName/:event", getAllImagesViaEventId);
router.delete("/deleteCartItems/:userId", deleteCart);
router.post("/verify-payment", verifyPayment);
router.put("/update-order/:orderId", updateStatus);
router.get("/downloadImages", downloadImages);
router.get("/getLastReceipt", getLastReceipt);  
router.post("/adminRegister", adminRegister);



export { router as authRoutes };
